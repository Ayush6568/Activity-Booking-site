const express = require('express');
const router = express.Router();
const { body, validationResult } = require('express-validator');
const Activity = require('../models/Activity');
const { protect } = require('../middleware/auth');

// Get all activities (public)
router.get('/', async (req, res) => {
  try {
    const activities = await Activity.find().sort({ dateTime: 1 });
    res.json(activities);
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Create new activity (protected)
router.post('/', [
  protect,
  body('title').trim().notEmpty().withMessage('Title is required'),
  body('description').trim().notEmpty().withMessage('Description is required'),
  body('location').trim().notEmpty().withMessage('Location is required'),
  body('dateTime').isISO8601().withMessage('Please provide a valid date and time')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const activity = await Activity.create(req.body);
    res.status(201).json(activity);
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router; 